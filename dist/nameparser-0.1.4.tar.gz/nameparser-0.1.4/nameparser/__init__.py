VERSION = (0, 1, 4)
__version__ = '.'.join(map(str, VERSION))
__author__ = "Derek Gulbranson"
__author_email__ = 'derek73@gmail.com'
__revision__ = "$Id: nameparser.py 25 2010-08-18 19:57:57Z derek73 $"
__license__ = "LGPL"
__url__ = "http://code.google.com/p/python-nameparser"

from parser import HumanName
