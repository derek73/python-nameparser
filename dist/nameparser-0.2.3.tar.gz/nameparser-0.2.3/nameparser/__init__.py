VERSION = (0, 2, 3)
__version__ = '.'.join(map(str, VERSION))
__author__ = "Derek Gulbranson"
__author_email__ = 'derek73@gmail.com'
__license__ = "LGPL"
__url__ = "http://code.google.com/p/python-nameparser"

from parser import HumanName
